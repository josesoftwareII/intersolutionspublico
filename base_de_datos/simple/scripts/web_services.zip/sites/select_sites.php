<?php
include '../lib/select.php';
select("SELECT id_ubicated,name_site,cost_site,description_site,link_image_site FROM sites");
?>
